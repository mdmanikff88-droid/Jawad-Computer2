JAWAD COMPUTER - NETLIFY VERIFIED ORDER FORM

Upload this ZIP as a new deploy.
Netlify Forms: Site configuration > Forms > Form detection must be enabled.
The form name is jawad-order everywhere.
Do not use the previous ZIP.
